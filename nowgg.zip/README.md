## Deployments

[![Deploy to Replit](https://binbashbanana.github.io/deploy-buttons/buttons/remade/replit.svg)](https://replit.com/github/astralevolution/nowus)

## PC Deployments

```sh
git clone https://github.com/astralevolution/nowgg
cd nowgg
npm install
node .
```
